import UIKit

/*:
 ### Example
 */
var str = "Hello, playground"

var message = "Hello, World!"
print(message)

message = "My Message!"
print(message)

/*:
 ### Exercise
 
 1.  Create a new variable ( var ) that stores your name
 2.  Print the variable
 */
